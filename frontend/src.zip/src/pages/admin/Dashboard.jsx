import { useState, useEffect } from 'react';
import { Package, ShoppingCart, FileText, Users, TrendingUp, DollarSign } from 'lucide-react';
import AdminLayout from '../../components/layout/AdminLayout';
import PageHeader from '../../components/layout/PageHeader';
import StatsCard from '../../components/admin/StatsCard';
import LoadingSpinner from '../../components/layout/LoadingSpinner';
import { ordersAPI, quotesAPI, customersAPI } from '../../api';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const [stats, setStats] = useState({
    orders: null,
    quotes: null,
    customers: null,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const [ordersRes, quotesRes, customersRes] = await Promise.all([
        ordersAPI.getOrderStatistics(),
        quotesAPI.getQuoteStatistics(),
        customersAPI.getCustomerStatistics(),
      ]);

      setStats({
        orders: ordersRes,
        quotes: quotesRes,
        customers: customersRes,
      });
    } catch (error) {
      console.error('Failed to fetch stats:', error);
      toast.error('Failed to load dashboard statistics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <LoadingSpinner fullScreen />
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <PageHeader
        title="Dashboard"
        subtitle="Welcome back! Here's what's happening today."
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {/* Total Revenue */}
        <StatsCard
          title="Total Revenue"
          value={`KSh ${(stats.orders?.total_revenue || 0).toLocaleString()}`}
          icon={DollarSign}
          color="success"
          trend="up"
          trendValue="+12% from last month"
        />

        {/* Total Orders */}
        <StatsCard
          title="Total Orders"
          value={stats.orders?.total_orders || 0}
          icon={ShoppingCart}
          color="primary"
        />

        {/* Pending Orders */}
        <StatsCard
          title="Pending Orders"
          value={stats.orders?.pending || 0}
          icon={Package}
          color="warning"
        />

        {/* Total Customers */}
        <StatsCard
          title="Total Customers"
          value={stats.customers?.total_customers || 0}
          icon={Users}
          color="info"
        />

        {/* Pending Quotes */}
        <StatsCard
          title="Pending Quotes"
          value={stats.quotes?.pending || 0}
          icon={FileText}
          color="warning"
        />

        {/* Quote Conversion */}
        <StatsCard
          title="Quote Conversion"
          value={`${stats.quotes?.conversion_rate || 0}%`}
          icon={TrendingUp}
          color="success"
        />
      </div>

      {/* Today's Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Today's Orders */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Today's Performance
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Orders Today</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                {stats.orders?.today || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Revenue Today</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                KSh {(stats.orders?.today_revenue || 0).toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Avg Order Value</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                KSh {(stats.orders?.average_order_value || 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Order Status Breakdown */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Order Status
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Confirmed</span>
              <span className="font-semibold text-blue-500">
                {stats.orders?.confirmed || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Processing</span>
              <span className="font-semibold text-yellow-500">
                {stats.orders?.processing || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Shipped</span>
              <span className="font-semibold text-primary-500">
                {stats.orders?.shipped || 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Delivered</span>
              <span className="font-semibold text-green-500">
                {stats.orders?.delivered || 0}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Status */}
      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Payment Overview
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
              Unpaid Amount
            </p>
            <p className="text-2xl font-bold text-red-500">
              KSh {(stats.orders?.unpaid_amount || 0).toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
              Total Paid
            </p>
            <p className="text-2xl font-bold text-green-500">
              KSh {(stats.orders?.total_revenue || 0).toLocaleString()}
            </p>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}